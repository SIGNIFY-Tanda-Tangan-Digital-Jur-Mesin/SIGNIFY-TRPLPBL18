<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;

class adminController extends Controller
{
    public function index(Request $request) {
        return view('pages.admin');
    }

    public function store(Request $request)
    {
        $request->validate([
            'role' => 'required|in:user,admin',
            'username' => 'required|string|max:255|unique:user,username',
            'password' => 'required|string|min:6'
        ]);

        $user = new User();
        $user->role = $request->role;
        $user->username = $request->username;
        $user->password = Hash::make($request->password);
        $user->id_user = Str::uuid() ;
        $user->save();

        return redirect()->back()->with('success', 'User created successfully.');
    }
}
