<?php

namespace App\Http\Controllers;

use App\Models\QrCode;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class SignifyController extends Controller
{
    public function store(Request $request) {
        $user = Auth::user();
        $request->validate([
            'tanggal' => 'required',
            'perihal' => 'required'
        ]);
        
        $qrCode = new QrCode;

        $qrCode->id_qrcode = Str::uuid();
        $qrCode->kode_qr = Str::uuid();
        $qrCode->tanggal = $request->tanggal;
        $qrCode->id_user = $user->id_user;
        $qrCode->perihal = $request->perihal;
        $qrCode->save();

        return redirect()->back();
    }

    public function destroy(Request $request, $Id) {
        QrCode::destroy($Id);
        // $qrCode = QrCode::find('id_qrcode', $Id);
        // $qrCode->delete();

        return redirect()->back()->with('success', 'QR Code deleted successfully');
    }

}

