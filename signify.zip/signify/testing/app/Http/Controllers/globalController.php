<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\User;

use App\Models\QrCode;

class globalController extends Controller
{
    public function index(Request $request) {
        $sessionUser = $request->session()->get('user');
        $user = User::findOrFail($sessionUser->id_user);
        $route = $request->route()->getName();
        $qrcode = QrCode::all();
        if ($route == 'index') return view('index', ['qrcode'=>$qrcode, 'user' => $user, 'now' => Carbon::now()->format('Y-m-d')]);
        elseif ($route == 'profil') return  view('pages.features-profile', ['user' => $user]);  
        return redirect()->route('profil');
    }

    public function update(Request $request, $id_user) {
        $request->validate([
            'username' => 'required|string|max:20'
        ]);

        $user = User::findOrFail($id_user);
        $user->username = $request->username;
        $user->save();
        return redirect()->route('profil')->with('success', 'Profil berhasil diperbarui');
    }

    public function showProfile($id_user) {
        $user = User::find($id_user);
        if (!$user) {
            abort(404);
        }
    
        return redirect()->route('profil');
    }
}
