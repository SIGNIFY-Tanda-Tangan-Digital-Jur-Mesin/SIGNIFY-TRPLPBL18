<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Users;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class UserController extends Controller
{
    /**
     * Display a listing of the users.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $users = Users::all();
        return response()->json($users);
    }

    /**
     * Store a newly created user in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    public function create() {
        return view('pages.login');
    }

    public function store(Request $request)
    {
        $request->validate([
            'username' => 'required|string|max:20|unique:users',
            'password' => 'required|string|max:50',
            'role' => 'required|in:admin,user',
        ]);

        $user = Users::create([
            'id_user' => Str::uuid(), // Generate a unique ID for id_user
            'username' => $request->username,
            'password' => Hash::make($request->password), // Hash the password
            'role' => $request->role,
        ]);

        return response()->json($user, 201);
    }

    /**
     * Display the specified user.
     *
     * @param  string  $id_user
     * @return \Illuminate\Http\Response
     */
    public function show($id_user)
    {
        $user = Users::find($id_user);

        if (!$user) {
            return response()->json(['message' => 'User not found'], 404);
        }

        return response()->json($user);
    }

    /**
     * Update the specified user in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  string  $id_user
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id_user)
    {
        $user = Users::find($id_user);

        if (!$user) {
            return response()->json(['message' => 'User not found'], 404);
        }

        $request->validate([
            'username' => 'sometimes|required|string|max:20|unique:users,username,' . $id_user . ',id_user',
            'password' => 'sometimes|required|string|max:50',
            'role' => 'sometimes|required|in:admin,user',
        ]);

        if ($request->has('username')) {
            $user->username = $request->username;
        }

        if ($request->has('password')) {
            $user->password = Hash::make($request->password);
        }

        if ($request->has('role')) {
            $user->role = $request->role;
        }

        $user->save();

        return response()->json($user);
    }

    /**
     * Remove the specified user from storage.
     *
     * @param  string  $id_user
     * @return \Illuminate\Http\Response
     */
    public function destroy($id_user)
    {
        $user = Users::find($id_user);

        if (!$user) {
            return response()->json(['message' => 'User not found'], 404);
        }

        $user->delete();

        return response()->json(['message' => 'User deleted successfully']);
    }
}
