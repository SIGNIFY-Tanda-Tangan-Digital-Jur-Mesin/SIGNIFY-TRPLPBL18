<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Signify; // Pastikan namespace ini benar

class TtdController extends Controller
{
    // Method untuk menampilkan data
    public function index()
    {
        $qrcode = Signify::all();
        return view('signify.index', compact('qrcode'));
    }

    // Method untuk menyimpan data
    public function store(Request $request)
    {
        $request->validate([
            'tanggal' => 'required|date',
            'nama' => 'required|string|max:255',
            'perihal' => 'required|string|max:255',
        ]);

        Signify::create($request->all());

        return redirect()->route('signify.index');
    }

    // Method untuk menghapus data
    public function destroy($id)
    {
        Signify::findOrFail($id)->delete();
        return redirect()->route('signify.index');
    }
}
