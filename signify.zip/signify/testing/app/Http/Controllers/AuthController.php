<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\User; // Import your User model

class AuthController extends Controller
{

    public function checkAuth(Request $request) {
        $user = $request->session()->get('user');
        if (!$user) return redirect('/login')->with('error', 'Please login first!'); 
    }

    public function showLoginForm()
    {
        $users = User::all(); // Fetch all users from the database
        return view('pages.login', ['users' => $users]);
    }

    // public function login(Request $request)
    // {
        
    //     $users = User::all();
    //     foreach ($users as $user) {
    //         if ($request->username == $user->username && $request->password == $user->password && $request->role == $user->role) {
    //             $user = Auth::user();
    //             dd($user);
    //             $request->session()->put('user', [
    //                 'id' => $user->id_user,
    //                 'username' => $user->username,
    //                 'role' => $user->role,
    //             ]);
    //             return redirect()->route('index')->with('message', 'login successfully');
    //         } else return redirect()->route('login')->with('error', 'Invalid credentials');
    //     }
    // }

    public function login(Request $request)
    {

        // User::create([
        //     'username' => 'Maximus',
        //     'password' => Hash::make('123'),
        //     'role' => 'admin',
        // ]);
        
        $request->validate([
            'username' => 'required',
            'password' => 'required',
            // 'role' => 'required',
        ]);

        $credentials = $request->only('username', 'password');
        if (Auth::attempt($credentials)) {
            $user = Auth::user();
            if ($user->role === $request->role) {
                $request->session()->put('user', $user);
                return redirect()->route('index');
            }
        }

        return redirect()->route('login')->withErrors('Invalid credentials');
    }


    public function logout(Request $request) {
        $request->session()->flush();
        return redirect('/index')->with('message', 'You have been logged Out');
    }
}
