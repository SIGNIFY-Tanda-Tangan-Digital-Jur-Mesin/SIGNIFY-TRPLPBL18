<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ttd extends Model
{
    use HasFactory;
}// app/Models/Signify.php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Signify extends Model
{
    use HasFactory;

    protected $fillable = ['tanggal', 'nama', 'perihal'];
}

