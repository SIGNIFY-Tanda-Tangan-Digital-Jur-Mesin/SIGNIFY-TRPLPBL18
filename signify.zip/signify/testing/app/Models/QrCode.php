<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class QrCode extends Model
{
    use HasFactory;
    protected $table = 'qr_code';
    protected $primaryKey = 'id_qrcode';
    public $incrementing = false;
    protected $keyType = 'string';

    public function DimilikiUser () {
        return $this->belongsTo(User::class, 'id_user', 'id_user');
    }
}
