<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Features Profile</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <style>
    /* Stisla CSS */
    body {
      font-family: 'Nunito', sans-serif;
      background-color: #f4f6f9;
      color: #6c757d;
      margin: 0;
      padding: 0;
    }
    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 20px;
    }
    .card {
      background: #fff;
      box-shadow: 0 2px 3px rgba(0, 0, 0, 0.1);
      border-radius: 8px;
      margin-bottom: 20px;
      overflow: hidden;
    }
    .card-header {
      padding: 20px;
      background: linear-gradient(135deg, #d4a5f7, #c27ef3);
      color: #fff;
    }
    .card-body {
      padding: 20px;
    }
    .profile-header {
      display: flex;
      align-items: center;
      margin-bottom: 20px;
    }
    .profile-header img {
      width: 100px;
      height: 100px;
      border-radius: 50%;
      margin-right: 20px;
    }
    .profile-header h1 {
      margin: 0;
    }
    .profile-details {
      display: flex;
      flex-wrap: wrap;
    }
    .profile-details .detail-item {
      flex: 1;
      margin-bottom: 10px;
    }
    .profile-details .detail-item label {
      font-weight: bold;
    }
    .edit-button, .save-button, .cancel-button {
      display: block;
      margin: 10px 0;
      padding: 10px;
      text-align: center;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
    .edit-button {
      background: linear-gradient(135deg, #d4a5f7, #c27ef3);
      color: #fff;
    }
    .save-button {
      background: linear-gradient(135deg, #a8e063, #56ab2f);
      color: #fff;
    }
    .cancel-button {
      background: linear-gradient(135deg, #ff758c, #ff7eb3);
      color: #fff;
    }
    .edit-form {
      display: none;
      margin-top: 20px;
    }
    .edit-form input, .edit-form textarea {
      width: 100%;
      padding: 10px;
      margin: 5px 0;
      border: 1px solid #ccc;
      border-radius: 5px;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="card">
      <div class="card-header">
        <h2>Profile</h2>
      </div>
      <div class="card-body">
        <div class="profile-header">
          <img id="profile-pic" src="profile-picture.jpg" alt="Profile Picture">
          <div>
            <h1 id="profile-name">John Doe</h1>
            <p id="profile-job">Web Developer</p>
          </div>
        </div>
        <div class="profile-details">
          <div class="detail-item">
            <label>Email:</label>
            <p id="profile-email">johndoe@example.com</p>
          </div>
          <div class="detail-item">
            <label>Phone:</label>
            <p id="profile-phone">(123) 456-7890</p>
          </div>
          <div class="detail-item">
            <label>Location:</label>
            <p id="profile-location">New York, USA</p>
          </div>
        </div>
        <button class="edit-button" onclick="toggleEditForm()">Edit Profile</button>

        <div class="edit-form" id="edit-form">
          <input type="text" id="edit-name" placeholder="Name" value="John Doe">
          <input type="text" id="edit-job" placeholder="Job" value="Web Developer">
          <input type="email" id="edit-email" placeholder="Email" value="johndoe@example.com">
          <input type="tel" id="edit-phone" placeholder="Phone" value="(123) 456-7890">
          <input type="text" id="edit-location" placeholder="Location" value="New York, USA">
          <input type="file" id="edit-profile-pic" accept="image/*">
          <button class="save-button" onclick="saveProfile()">Save</button>
          <button class="cancel-button" onclick="toggleEditForm()">Cancel</button>
        </div>
      </div>
    </div>
  </div>

  <script>
    function toggleEditForm() {
      const editForm = document.getElementById('edit-form');
      editForm.style.display = editForm.style.display === 'none' || editForm.style.display === '' ? 'block' : 'none';
    }

    function saveProfile() {
      const name = document.getElementById('edit-name').value;
      const job = document.getElementById('edit-job').value;
      const email = document.getElementById('edit-email').value;
      const phone = document.getElementById('edit-phone').value;
      const location = document.getElementById('edit-location').value;
      const profilePicInput = document.getElementById('edit-profile-pic');

      document.getElementById('profile-name').innerText = name;
      document.getElementById('profile-job').innerText = job;
      document.getElementById('profile-email').innerText = email;
      document.getElementById('profile-phone').innerText = phone;
      document.getElementById('profile-location').innerText = location;

      if (profilePicInput.files && profilePicInput.files[0]) {
        const reader = new FileReader();
        reader.onload = function (e) {
          document.getElementById('profile-pic').src = e.target.result;
        };
        reader.readAsDataURL(profilePicInput.files[0]);
      }

      toggleEditForm();
    }
  </script>
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\testing\resources\views/pages/features-profile.blade.php ENDPATH**/ ?>