<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>QR Code Scanner</title>

  <!-- Link CSS untuk styling -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.1/normalize.min.css">
  <style>
    body {
      font-family: Arial, sans-serif;
      text-align: center;
      padding: 50px;
    }

    #scanner-container {
      position: relative;
      width: 100%;
      max-width: 600px;
      margin: 0 auto;
    }

    #scanner {
      width: 100%;
      height: 300px;
      border: 2px solid #333;
      margin-bottom: 20px;
    }

    #scan-btn {
      display: inline-block;
      padding: 10px 20px;
      background-color: #007bff;
      color: #fff;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      margin-bottom: 20px;
    }

    #upload-btn {
      display: inline-block;
      padding: 10px 20px;
      background-color: #28a745;
      color: #fff;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      margin-bottom: 20px;
    }
  </style>
</head>

<body>
  <h1>QR Code Scanner</h1>

  <!-- Container untuk scanner QR Code -->
  <div id="scanner-container">
    <video id="scanner"></video>
  </div>

  <!-- Tombol untuk mulai scan -->
  <button id="scan-btn">Mulai Scan</button>

  <!-- Tombol untuk unggah gambar -->
  <input type="file" id="upload-input" accept="image/png" style="display: none;">
  <button id="upload-btn">Unggah Gambar</button>

  <!-- Script untuk Instascan -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/instascan/1.0.1/instascan.min.js"></script>
  <script>
    const scanner = new Instascan.Scanner({
      video: document.getElementById('scanner'),
      mirror: false
    });

    // Callback saat QR Code terdeteksi
    scanner.addListener('scan', function (content) {
      alert('QR Code Terdeteksi: ' + content);
    });

    // Tombol untuk mulai scan
    document.getElementById('scan-btn').addEventListener('click', function () {
      Instascan.Camera.getCameras().then(function (cameras) {
        if (cameras.length > 0) {
          scanner.start(cameras[0]);
        } else {
          alert('Kamera tidak ditemukan!');
        }
      }).catch(function (e) {
        alert('Error: ' + e);
      });
    });

    // Tombol untuk unggah gambar
    document.getElementById('upload-btn').addEventListener('click', function () {
      document.getElementById('upload-input').click();
    });

    // Callback saat gambar diunggah dipilih
    document.getElementById('upload-input').addEventListener('change', function (event) {
      const file = event.target.files[0];
      if (file && file.type === 'image/png') {
        const reader = new FileReader();
        reader.onload = function (e) {
          const img = new Image();
          img.onload = function () {
            // Tampilkan gambar yang diunggah di elemen img
            document.body.appendChild(img);
          };
          img.src = e.target.result;
        };
        reader.readAsDataURL(file);
      } else {
        alert('Mohon unggah gambar PNG.');
      }
    });

    // Meminta izin menggunakan kamera saat dokumen dimuat
    document.addEventListener('DOMContentLoaded', function () {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        alert('Peramban tidak mendukung akses kamera.');
        return;
      }

      navigator.mediaDevices.getUserMedia({
        video: true
      }).then(function (stream) {
        // Mengatur stream video ke elemen video scanner
        document.getElementById('scanner').srcObject = stream;
      }).catch(function (error) {
        alert('Tidak dapat mengakses kamera: ' + error);
      });
    });
  </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\laravel\testing\resources\views/pages/scanner.blade.php ENDPATH**/ ?>