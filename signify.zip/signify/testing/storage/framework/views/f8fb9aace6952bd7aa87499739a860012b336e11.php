<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Detail Informasi</title>
  <style>
    body {
      font-family: 'Arial', sans-serif;
      background-color: #eef2f7;
      margin: 0;
      padding: 20px;
    }

    .container {
      background-color: #fff;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      text-align: center;
      width: 80%;
      max-width: 500px;
      margin: 0 auto;
      border-top: 10px solid #6a1b9a;
    }

    h1 {
      font-size: 28px;
      color: #6a1b9a;
      margin-bottom: 20px;
    }

    .info {
      text-align: left;
      font-size: 16px;
      color: #555;
      margin-top: 20px;
    }

    .info p {
      margin: 10px 0;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #ddd;
      padding-bottom: 5px;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Detail Informasi</h1>
    <div class="info">
      <p><strong>Nama:</strong><?php echo e($qrcode->DimilikiUser->username); ?>  <span id="nama"></span></p>
      <p><strong>Tanggal:</strong><?php echo e($qrcode->tanggal); ?> <span id="tanggal"></span></p>
      <p><strong>Perihal:</strong><?php echo e($qrcode->perihal); ?>  <span id="perihal"></span></p>
    </div>
  </div>

  <script>
    // Mendapatkan parameter query
    const urlParams = new URLSearchParams(window.location.search);
    const nama = urlParams.get('nama');
    const tanggal = urlParams.get('tanggal');
    const perihal = urlParams.get('perihal');

    // Menampilkan data di halaman
    document.getElementById('nama').textContent = nama;
    document.getElementById('tanggal').textContent = tanggal;
    document.getElementById('perihal').textContent = perihal;
  </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\signify\testing\resources\views/pages/info.blade.php ENDPATH**/ ?>