<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>QR Code Generator with Logo</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.1/normalize.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <style>
    /* Global CSS */
    body {
      font-family: 'Arial', sans-serif;
      background-color: #eef2f7;
      margin: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    /* Container Styling */
    .container {
      background-color: #fff;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      text-align: center;
      width: 80%;
      max-width: 500px;
      transition: transform 0.2s;
      border-top: 10px solid #6a1b9a;
    }

    .container:hover {
      transform: scale(1.02);
    }

    /* Heading Styling */
    h1 {
      font-size: 28px;
      color: #6a1b9a;
      margin-bottom: 20px;
    }

    /* Info Styling */
    .info {
      text-align: left;
      font-size: 16px;
      color: #555;
      margin-top: 20px;
      padding-top: 20px;
      border-top: 1px solid #ddd;
    }

    .info p {
      margin: 10px 0;
      font-family: 'Montserrat', sans-serif; /* Apply Montserrat font */
    }

    .info p strong {
      flex: 1; /* Let the strong tag take full width of its container */
      text-align: left; /* Align text to the left */
      margin-right: 10px; /* Add some space between strong tag and span */
    }

    .info p span {
      flex: 2; /* Let the span take two-thirds width of its container */
      text-align: left; /* Align text to the left */
    }

    /* QR Code Styling */
    #qr-code {
      margin-top: 20px;
      border: 6px solid #fff; /* Add some padding around the QR Code */
    }

    /* Download Button Styling */
    .download-btn {
      display: inline-block;
      margin-top: 20px;
      padding: 10px 20px;
      font-size: 16px;
      color: #fff;
      background-color: #6a1b9a;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      text-decoration: none;
      transition: background-color 0.3s;
    }

    .download-btn:hover {
      background-color: #4a0072;
    }

    /* Back to Index Link Styling */
    .back-link {
      display: inline-block;
      margin-top: 20px;
      font-size: 14px;
      color: #555;
      text-decoration: none;
      padding: 10px 20px;
      border: 1px solid #6a1b9a;
      border-radius: 5px;
      transition: background-color 0.3s, color 0.3s;
    }

    .back-link:hover {
      background-color: #6a1b9a;
      color: #fff;
    }

    /* Responsive Adjustments */
    @media (max-width: 600px) {
      .container {
        width: 90%;
      }

      h1 {
        font-size: 24px;
      }

      .info p {
        font-size: 14px;
      }
    }
  </style>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
</head>
<body>
  <div class="container">
    <h1>QR Code Generator</h1>
    <canvas id="qr-code"></canvas>
    <div class="info">
      <p><strong>Ditanda tangani oleh:</strong> <span id="tte"><?php echo e($qrcode->DimilikiUser->username); ?></span></p>
      <p><strong>Tanggal:</strong> <span id="tanggal"><?php echo e($qrcode->tanggal); ?></span></p>
      <p><strong>Perihal:</strong> <span id="perihal"><?php echo e($qrcode->perihal); ?></span></p>
      <p><strong>Pindai QR code untuk verifikasi</strong></p>
    </div>
    <a id="download-btn" class="download-btn" href="#">Download QR Code</a>
            <a href="<?php echo e(route('index')); ?>" class="btn btn-secondary mt-3">Back</a> <!-- Tombol Back -->
  </div>

  <!-- JavaScript -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/qrious/4.0.2/qrious.min.js"></script>
  <script>
    // Display data on the page
    document.addEventListener('DOMContentLoaded', function() {
      const nama = "<?php echo e($qrcode->DimilikiUser->username); ?>";
      const tanggal = "<?php echo e($qrcode->tanggal); ?>";
      const perihal = "<?php echo e($qrcode->perihal); ?>";

      document.getElementById('tte').textContent = nama;
      document.getElementById('tanggal').textContent = tanggal;
      document.getElementById('perihal').textContent = perihal;

      // URL target for the QR code
      const urlTarget = `<?php echo e(url('info', $qrcode->id_qrcode)); ?>`;

      // Generate QR code with the target URL
      const qr = new QRious({
        element: document.getElementById('qr-code'),
        value: urlTarget,
        size: 200,
        foreground: 'black', // QR Code color
        background: 'white'   // QR Code background color
      });

      // Function to download the QR code as PNG
      document.getElementById('download-btn').addEventListener('click', function(e) {
        e.preventDefault(); // Prevent default link behavior
        const canvas = document.getElementById('qr-code');
        canvas.toBlob(function(blob) {
          const url = URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.href = url;
          link.download = 'qrcode.png';
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          URL.revokeObjectURL(url); // Clean up
        });
      });
    });
  </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\signify\testing\resources\views/pages/qrcode.blade.php ENDPATH**/ ?>