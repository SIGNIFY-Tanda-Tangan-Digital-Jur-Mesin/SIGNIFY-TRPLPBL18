<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qrcode_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} else {
    echo "Connected successfully<br>";
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama'];
    $tanggal = $_POST['tanggal'];
    $perihal = $_POST['perihal'];
    $qrcode_path = 'qrcodes/' . uniqid() . '.png';

    // Generate QR code
    include 'phpqrcode/qrlib.php';
    QRcode::png("pages/info.php?nama=$nama&tanggal=$tanggal&perihal=$perihal", $qrcode_path);

    // Save to database
    $sql = "INSERT INTO qrcodes (tanggal, perihal, qrcode_path) VALUES ('$tanggal', '$perihal', '$qrcode_path')";
    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully<br>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$sql = "SELECT * FROM qrcodes";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    echo "Data fetched successfully<br>";
} else {
    echo "No data found<br>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Code Generator with Logo</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.1/normalize.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        input[type="text"],
        input[type="date"] {
            padding: 10px;
            width: calc(100% - 20px);
            margin: 5px;
            font-size: 16px;
        }

        button {
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ccc;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f4f4f4;
        }

        img {
            width: 100px;
            height: 100px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>QR Code Generator with Logo</h1>
        <form method="POST" action="generate_qrcode.php">
            <div class="form-group">
                <input type="text" name="nama" id="nama" placeholder="Nama yang memberikan ttd">
            </div>
            <div class="form-group">
                <input type="date" name="tanggal" id="tanggal">
            </div>
            <div class="form-group">
                <input type="text" name="perihal" id="perihal" placeholder="Perihal">
            </div>
            <button type="submit">Generate QR Code</button>
        </form>
        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>ID</th>
                    <th>Tanggal</th>
                    <th>Perihal</th>
                    <th>QR Code</th>
                    <th>Download</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    $no = 1;
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $no++ . "</td>";
                        echo "<td>" . $row['id'] . "</td>";
                        echo "<td>" . $row['tanggal'] . "</td>";
                        echo "<td>" . $row['perihal'] . "</td>";
                        echo "<td><a href='pages/info.php?id=" . $row['id'] . "'><img src='" . $row['qrcode_path'] . "' alt='QR Code'></a></td>";
                        echo "<td><a href='" . $row['qrcode_path'] . "' download>Download</a></td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='6'>No QR codes generated yet.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\testing\resources\views/pages/tabel.blade.php ENDPATH**/ ?>