<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Persetujuan Kode QR</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            border: 1px dashed black;
            padding: 20px;
            width: 300px;
            text-align: center;
        }
        .header, .content, .footer {
            margin-bottom: 20px;
        }
        .qr-code {
            width: 200px;
            height: 200px;
        }
        .note {
            font-size: 12px;
            color: grey;
            margin: 10px 0;
        }
        button {
            padding: 10px 20px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h3>TTE oleh:</h3>
            <p><b>SUPARDIANTO</b><br>31 Mei 2024</p>
        </div>
        <div class="content">
            <img src="path/to/your/qrcode.png" alt="Kode QR" class="qr-code" id="qrcode">
            <p><b>Perihal oleh:</b><br>Persetujuan Logbook magang mahasiswa PS Team Minggu Ke-4 Mei 2024</p>
        </div>
        <div class="footer">
            <p>Pindai Kode QR untuk Verifikasi.<br>Pastikan URL di if.polibatam.ac.id/approval</p>
            <p class="note">Ambil tangkapan layar di dalam garis batas ini</p>
            <button onclick="takeScreenshot()">Unduh/Tangkapan Layar</button>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>
    <script>
        // Ganti ini dengan sumber Kode QR yang sebenarnya
        document.getElementById('qrcode').src = 'path/to/your/dynamic/qrcode.png';

        function takeScreenshot() {
            html2canvas(document.querySelector('.container')).then(canvas => {
                let link = document.createElement('a');
                link.download = 'screenshot.png';
                link.href = canvas.toDataURL();
                link.click();
            });
        }
    </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\testing\resources\views/pages/qrcode.blade.php ENDPATH**/ ?>