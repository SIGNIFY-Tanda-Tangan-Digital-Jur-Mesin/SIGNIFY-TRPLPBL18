<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Detail Kode QR</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.1/normalize.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <style>
    body {
      font-family: Arial, sans-serif;
      text-align: center;
      background-color: #f0f0f0;
      margin: 0;
      padding: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    .container {
      max-width: 800px;
      width: 100%;
      padding: 20px;
      background-color: #fff;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    h1 {
      margin-bottom: 20px;
      color: #1976d2;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      border-radius: 10px;
      overflow: hidden;
    }

    th, td {
      padding: 15px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }

    th {
      background-color: #1976d2;
      color: #fff;
    }

    tr:nth-child(even) {
      background-color: #f2f2f2;
    }

    img {
      width: 200px;
      height: 200px;
      margin-top: 20px;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      transition: transform 0.3s ease;
    }

    img:hover {
      transform: scale(1.1);
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Detail Kode QR</h1>
    <table>
      <tr>
        <th>Nama</th>
        <td id="detailNama"></td>
      </tr>
      <tr>
        <th>Tanggal</th>
        <td id="detailTanggal"></td>
      </tr>
      <tr>
        <th>Perihal</th>
        <td id="detailPerihal"></td>
      </tr>
    </table>
    <img id="detailQRCode" src="" alt="Kode QR">
  </div>

  <script>
    document.addEventListener('DOMContentLoaded', function() {
      // Ambil data dari localStorage
      var detailData = JSON.parse(localStorage.getItem('detailData'));
      if (detailData) {
        document.getElementById('detailNama').textContent = detailData.nama;
        document.getElementById('detailTanggal').textContent = detailData.tanggal;
        document.getElementById('detailPerihal').textContent = detailData.perihal;
        document.getElementById('detailQRCode').src = detailData.qrCodeDataURL;
      } else {
        alert('Tidak ada data untuk ditampilkan.');
      }
    });
  </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\testing\resources\views/pages/info.blade.php ENDPATH**/ ?>