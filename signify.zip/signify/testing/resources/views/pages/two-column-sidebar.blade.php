<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Approval</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        header {
            background-color: #333;
            color: white;
            padding: 10px 0;
        }

        header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 90%;
            margin: 0 auto;
        }

        header h1 {
            margin: 0;
        }

        header nav {
            display: flex;
            align-items: center;
        }

        header nav a {
            color: white;
            text-decoration: none;
            margin-left: 20px;
        }

        header nav input {
            margin-left: 20px;
            padding: 5px;
        }

        .breadcrumb {
            padding: 10px 0;
            background-color: #eee;
            width: 90%;
            margin: 10px auto;
        }

        .breadcrumb a {
            text-decoration: none;
            color: #333;
        }

        .breadcrumb span {
            color: #999;
        }

        main {
            width: 90%;
            margin: 20px auto;
        }

        .approval-details {
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .approval-details h2 {
            margin-top: 0;
        }

        .data-approval {
            margin-top: 20px;
        }

        .data-approval .row {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }

        .data-approval .row span {
            font-weight: bold;
        }

        .data-approval .row span:last-child {
            font-weight: normal;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1>SIGNIFY</h1>
            <nav>
                <a href="#">Home</a>
                <a href="#">Contact</a>
                <input type="text" placeholder="Search">
            </nav>
        </div>
    </header>
    <main>
        <div class="breadcrumb">
            <a href="#">Home</a> / <span>Detail Approval</span>
        </div>
        <section class="approval-details">
            <h2>Detail Approval</h2>
            <div class="data-approval">
                <div class="row">
                    <span>Nomor Surat:</span>
                    <span>S3621</span>
                </div>
                <div class="row">
                    <span>Tanggal:</span>
                    <span>31-05-2024</span>
                </div>
                <div class="row">
                    <span>Pemberi Approval:</span>
                    <span>SUPARDIANTO</span>
                </div>
                <div class="row">
                    <span>Perihal:</span>
                    <span>Persetujuan Logbook magang mahasiswa PSTeam Minggu Ke-4 Mei 2024</span>
                </div>
            </div>
        </section>
    </main>
</body>
</html>
