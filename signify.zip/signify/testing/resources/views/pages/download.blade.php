<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>PBL018-SIGNIFY</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top header-transparent">
    <div class="container d-flex align-items-center justify-content-between">

      <h1 class="logo"><a href="index.html">SIGNIFY</a></h1>
      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
          <li><a class="nav-link scrollto" href="#about">About</a></li>
          <li><a class="nav-link scrollto" href="#team">Team</a></li>
          <li><a class="getstarted scrollto" href="pages/login.html">Login</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">

    <div class="container-fluid" data-aos="fade-up">
      <div class="row justify-content-center">
        <div class="col-xl-5 col-lg-6 pt-3 pt-lg-0 order-2 order-lg-1 d-flex flex-column justify-content-center">
          <h1>TANDA TANGAN DIGITAL JURUSAN MESIN</h1>
          <h2>TANDA TANGAN BERBASIS QR CODE</h2>
          <div><a href="#about" class="btn-get-started scrollto">login</a></div>
        </div>
        <div class="col-xl-4 col-lg-6 order-1 order-lg-2 hero-img" data-aos="zoom-in" data-aos-delay="150">
          <img src="assets/img/code-img.png" class="img-fluid animated" alt="">
        </div>
      </div>
    </div>

  </section><!-- End Hero -->

  <!-- ======= Main ======= -->
  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <!-- Isi bagian about -->

    </section><!-- End About Section -->

    <!-- ======= Team Section ======= -->
    <section id="team" class="team">
      <!-- Isi bagian team -->

    </section><!-- End Team Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">
    <!-- Isi bagian footer -->

    <!-- Menu Download QR Code -->
    <div class="download-menu">
        <h3>Download QR Code:</h3>
        <button onclick="downloadQRCode('jpg')">Download JPG</button>
        <button onclick="downloadQRCode('png')">Download PNG</button>
        <button onclick="downloadQRCode('pdf')">Download PDF</button>
    </div>

    <!-- Menu Share on Media Sosial -->
    <div class="social-share-menu">
        <h3>Share on Social Media:</h3>
        <button onclick="shareOnSocialMedia('facebook')">Share on Facebook</button>
        <button onclick="shareOnSocialMedia('twitter')">Share on Twitter</button>
        <button onclick="shareOnSocialMedia('instagram')">Share on Instagram</button>
    </div>

    <!-- Menu Salin Tautan -->
    <div class="copy-link-menu">
        <h3>Copy Link:</h3>
        <button onclick="copyQRCodeLink()">Salin Tautan</button>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

  <!-- Script untuk menu Download QR Code, Share on Media Sosial, dan Salin Tautan -->
  <script>
    // Fungsi untuk mengunduh QR code dalam format tertentu
    function downloadQRCode(format) {
        // Implementasi logika untuk mengunduh QR code dalam format yang dipilih
    }

    // Fungsi untuk berbagi QR code ke media sosial
    function shareOnSocialMedia(platform) {
        // Implementasi logika untuk membuka tautan berbagi di media sosial yang dipilih
    }

    // Fungsi untuk menyalin tautan QR code ke clipboard
    function copyQRCodeLink() {
        // Implementasi logika untuk menyalin URL QR code ke clipboard
    }
  </script>
</body>

</html>
``
