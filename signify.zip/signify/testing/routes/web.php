<?php
use App\Http\Controllers\SignifyController;
use App\Models\QrCode;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\adminController;
use App\Http\Controllers\globalController;
use App\Http\Controllers\QrCodeController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::middleware(['auth'])->group(function () {
    Route::get('/index', [globalController::class, 'index'])->name('index');
    // Route::get('/get-qr', [globalController::class, 'index'])->name('get-qr');
    Route::get('/profil', [globalController::class, 'index'])->name('profil');
    Route::put('/editProfil/{id_user}', [globalController::class, 'update'])->name('editProfil');
    Route::get('/signify', [SignifyController::class, 'index'])->name('signify.index');
    Route::post('/signify', [SignifyController::class, 'store'])->name('signify.store');
    Route::delete('/signify/{id}', [SignifyController::class, 'destroy'])->name('signify.destroy');
});

Route::middleware(['admin'])->group(function () {
    Route::get('/admin', [adminController::class, 'index'])->name('admin');
    Route::post('/admin/create', [adminController::class, 'store'])->name('storeUser');
    // routes/web.php



    
});

Route::get('/', function () {
    return view('welcome');
});

Route::get('/homepage', function () {
    return view('homepage');
});

Route::get('/info', function () {
    return view('pages.info');
});

// Route::get('/login', function () {
//     return view('pages.login');
// });


Route::get('/info/{id_qrcode}', function ( $id_qrcode ) {

    if (!isset($id_qrcode)) {
        abort(404);
    }

    $qrcode = QrCode::where('id_qrcode', $id_qrcode)->first();

    if ( !$qrcode ) {
        return "no data";
    }

    return view('pages.info', ['qrcode' => $qrcode]);

});

Route::get('/qrcode/{id_qrcode}', function ( $id_qrcode ) {


    $qrcode = QrCode::where('id_qrcode', $id_qrcode)->first();

    if ( !$qrcode ) {
        return "no data";
    }

    return view('pages.qrcode', ['qrcode' => $qrcode]);
});

Route::get('/mini-column-sidebar', function () {
    return view('pages.mini-column-sidebar');
});

Route::get('/mini-plus-one-columns-sidebar', function () {
    return view('pages.mini-plus-one-column-sidebar');
});

Route::get('/two-column-sidebar', function () {
    return view('pages.two-column-sidebar');
});

Route::get('/logo', function () {
    return view('public.assets.img.logo');
});

Route::get('/tabel', function () {
    return view('pages.tabel');
});

Route::get('/scanner', function () {
    return view('pages.scanner');
});



// Route::get('login/create', [UserController::class, 'create'])->name('user.create');
// Route::post('login', [UserController::class, 'store'])->name('user.store');

Route::get('login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('login', [AuthController::class, 'login']);

Route::post('logout', [AuthController::class, 'logout'])->name('logout');
